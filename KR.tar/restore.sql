--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "KR";
--
-- Name: KR; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "KR" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Ukrainian_Ukraine.1251';


ALTER DATABASE "KR" OWNER TO postgres;

\connect "KR"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: equipData; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."equipData" (
    id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    price double precision DEFAULT 0.0,
    type text NOT NULL
);


ALTER TABLE public."equipData" OWNER TO postgres;

--
-- Name: equipData_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."equipData_id_seq"
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."equipData_id_seq" OWNER TO postgres;

--
-- Name: equipData_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."equipData_id_seq" OWNED BY public."equipData".id;


--
-- Name: loginData; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."loginData" (
    "uName" text NOT NULL,
    "uPass" text NOT NULL,
    admin boolean DEFAULT false NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public."loginData" OWNER TO postgres;

--
-- Name: loginData_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."loginData_id_seq"
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."loginData_id_seq" OWNER TO postgres;

--
-- Name: loginData_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."loginData_id_seq" OWNED BY public."loginData".id;


--
-- Name: loginequip; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loginequip (
    login_id integer NOT NULL,
    equip_id integer NOT NULL
);


ALTER TABLE public.loginequip OWNER TO postgres;

--
-- Name: types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.types (
    type text NOT NULL
);


ALTER TABLE public.types OWNER TO postgres;

--
-- Name: equipData id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."equipData" ALTER COLUMN id SET DEFAULT nextval('public."equipData_id_seq"'::regclass);


--
-- Name: loginData id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."loginData" ALTER COLUMN id SET DEFAULT nextval('public."loginData_id_seq"'::regclass);


--
-- Data for Name: equipData; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."equipData" (id, name, description, price, type) FROM stdin;
\.
COPY public."equipData" (id, name, description, price, type) FROM '$$PATH$$/4866.dat';

--
-- Data for Name: loginData; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."loginData" ("uName", "uPass", admin, id) FROM stdin;
\.
COPY public."loginData" ("uName", "uPass", admin, id) FROM '$$PATH$$/4864.dat';

--
-- Data for Name: loginequip; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loginequip (login_id, equip_id) FROM stdin;
\.
COPY public.loginequip (login_id, equip_id) FROM '$$PATH$$/4869.dat';

--
-- Data for Name: types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.types (type) FROM stdin;
\.
COPY public.types (type) FROM '$$PATH$$/4867.dat';

--
-- Name: equipData_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."equipData_id_seq"', 5, true);


--
-- Name: loginData_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."loginData_id_seq"', 4, true);


--
-- Name: loginequip loginequip_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loginequip
    ADD CONSTRAINT loginequip_pkey PRIMARY KEY (equip_id, login_id);


--
-- Name: equipData pr_equip_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."equipData"
    ADD CONSTRAINT pr_equip_id PRIMARY KEY (id);


--
-- Name: loginData pr_login_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."loginData"
    ADD CONSTRAINT pr_login_id PRIMARY KEY (id);


--
-- Name: types types_type_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_type_key UNIQUE (type);


--
-- Name: equipData uq_equip_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."equipData"
    ADD CONSTRAINT uq_equip_id UNIQUE (id);


--
-- Name: equipData uq_equipdata; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."equipData"
    ADD CONSTRAINT uq_equipdata UNIQUE (name);


--
-- Name: loginData uq_login_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."loginData"
    ADD CONSTRAINT uq_login_id UNIQUE (id);


--
-- Name: loginequip fk_equip; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loginequip
    ADD CONSTRAINT fk_equip FOREIGN KEY (equip_id) REFERENCES public."equipData"(id);


--
-- Name: loginequip fk_login; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loginequip
    ADD CONSTRAINT fk_login FOREIGN KEY (login_id) REFERENCES public."loginData"(id);


--
-- PostgreSQL database dump complete
--

